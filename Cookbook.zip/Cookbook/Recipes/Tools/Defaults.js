export const ACTIONS = {
  ADD: "add",
  UPDATE: "update",
  DELETE: "delete",
};

export const COLORS = {
  PRIMARY: "#246b7d",
  SECONDARY: "#ddd",
  TERTIARY: "gray",
  PRIMARY2: "#2d8fa8",
  SECONDARY2: "#ede8e8",
};
